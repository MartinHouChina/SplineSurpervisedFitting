from __future__ import annotations

import math
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest
import torch


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from spline_fitting.evaluation import published_baselines as baselines  # noqa: E402
from spline_fitting.evaluation.bspline_inference import (  # noqa: E402
    refit_bspline_control_points,
)


def _points() -> torch.Tensor:
    t = torch.linspace(0.0, 1.0, 25, dtype=torch.float64)
    return torch.stack([t, 0.15 * torch.sin(2.0 * torch.pi * t)], dim=-1)


def _collapse_regression_points() -> torch.Tensor:
    """Coastline-like curve whose native compression can retain 1--4 knots."""

    parameter = torch.linspace(0.0, 1.0, 96, dtype=torch.float64)
    points = torch.stack(
        [
            parameter,
            0.18 * torch.sin(4.0 * torch.pi * parameter)
            + 0.045 * torch.sin(17.0 * torch.pi * parameter),
        ],
        dim=-1,
    )
    lower = points.amin(dim=0)
    scale = (points.amax(dim=0) - lower).max()
    return (points - lower) / scale


def _run(method: str, **kwargs: object) -> baselines.PublishedBaselineResult:
    options = dict(
        mse_tolerance=1e-4,
        max_internal_knots=2,
        gradient_steps=1,
        paper_initial_knots=3,
        paper_admm_iterations=5,
        paper_lambda_bisections=1,
        paper_relocation_iterations=1,
        liang_dense_knots=4,
        liang_initial_knots=1,
        liang_feature_samples=33,
        dung_scan_intervals=2,
        dung_optimization_iterations=1,
        luo_de_population=5,
        luo_de_iterations=1,
    )
    options.update(kwargs)
    return baselines.run_published_baseline(method, _points(), **options)


@pytest.mark.parametrize("method", baselines.COMPARISON_BASELINE_METHODS)
def test_baselines_report_actual_spline_and_euclidean_mse(method: str) -> None:
    result = _run(method)
    points = _points()
    fit = result.fit
    reference = refit_bspline_control_points(
        result.parameters,
        points,
        fit.internal_knots,
        smoothness_weight=0.0,
        control_ridge=0.0,
        interpolate_endpoints=result.diagnostics["interpolate_endpoints"],
    )

    assert result.method == method
    assert result.elapsed_ms > 0.0 and math.isfinite(result.elapsed_ms)
    torch.testing.assert_close(fit.fit_mse, reference.fit_mse, atol=1e-14, rtol=1e-10)
    expected_mse = (fit.reconstructed_points - points).square().sum(dim=-1).mean()
    torch.testing.assert_close(fit.fit_mse, expected_mse)
    if result.diagnostics["interpolate_endpoints"]:
        torch.testing.assert_close(fit.reconstructed_points[[0, -1]], points[[0, -1]])
    assert result.diagnostics["network_used"] is False
    assert result.diagnostics["threshold_satisfied"] == (float(expected_mse) <= 1e-4)
    if method == "kang_sparse_2015_adaptation":
        assert result.diagnostics["non_paper_feasibility_repair_enabled"] is False
        assert result.diagnostics["paper_feasibility_repair_used"] is False
        assert "native_final_fit_mse_without_endpoint_constraint" in result.diagnostics
        assert result.diagnostics["native_endpoint_constrained_mse"] is None
        assert result.diagnostics["post_algorithm_endpoint_refit_applied"] is False
        assert result.diagnostics["relocated_internal_knot_count"] == sum(
            result.diagnostics["relocated_knot_multiplicities"]
        )
        assert result.diagnostics["relocated_unique_knot_count"] == len(
            result.diagnostics["relocated_knot_multiplicities"]
        )
        assert (
            result.diagnostics[
                "native_sparse_feasible_final_common_refit_failed"
            ]
            == (
                result.diagnostics["sparse_stage_threshold_satisfied"]
                and not result.diagnostics["threshold_satisfied"]
            )
        )
        assert result.diagnostics[
            "sparse_and_final_mse_are_directly_comparable"
        ] is False
    if method == "luo_linf_de_2022_adaptation":
        assert "dense_initial_fit_mse" in result.diagnostics
        assert "candidate_refit_mse_before_de" in result.diagnostics
    knot_cap = (
        3
        if method
        in {"kang_sparse_2015_adaptation", "luo_linf_de_2022_adaptation"}
        else 2
    )
    assert 0 <= fit.internal_knots.numel() <= knot_cap


def test_repository_numerical_control_is_not_mislabeled_as_published() -> None:
    assert "uniform_gradient_pruning" in baselines.NUMERICAL_BASELINE_METHODS
    assert "uniform_gradient_pruning" in baselines.COMPARISON_BASELINE_METHODS
    assert "uniform_gradient_pruning" not in baselines.PUBLISHED_ADAPTATION_METHODS
    assert baselines.PUBLISHED_BASELINE_METHODS == baselines.PUBLISHED_ADAPTATION_METHODS


def test_kang_timing_encloses_algorithm_without_extra_endpoint_refit(monkeypatch) -> None:
    events: list[str] = []

    def clock() -> float:
        if not events:
            events.append("start")
            return 10.0
        events.append("stop")
        return 13.0

    monkeypatch.setattr(baselines, "time", SimpleNamespace(perf_counter=clock))
    original_chord = baselines.chord_length_parameters
    original_sparse = baselines.fit_sparse_knots_paper
    original_refit = baselines.refit_bspline_control_points

    def chord(*args, **kwargs):
        events.append("parameterization")
        return original_chord(*args, **kwargs)

    def sparse(*args, **kwargs):
        events.append("search")
        assert kwargs["feasibility_repair"] is False
        return original_sparse(*args, **kwargs)

    def refit(*args, **kwargs):
        events.append("common_refit")
        return original_refit(*args, **kwargs)

    monkeypatch.setattr(baselines, "chord_length_parameters", chord)
    monkeypatch.setattr(baselines, "fit_sparse_knots_paper", sparse)
    monkeypatch.setattr(baselines, "refit_bspline_control_points", refit)
    result = _run("kang_sparse_2015_adaptation")

    assert events == ["start", "parameterization", "search", "stop"]
    assert result.elapsed_ms == 3000.0


def test_gradient_baseline_still_optimizes_inside_inference_mode() -> None:
    with torch.inference_mode():
        result = _run("uniform_gradient_pruning")
    assert result.diagnostics["variable_projection_evaluations"] > 0
    assert torch.isfinite(result.fit.fit_mse)


@pytest.mark.parametrize(
    "kwargs",
    [
        {"mse_tolerance": -1.0},
        {"mse_tolerance": float("nan")},
        {"max_internal_knots": -1},
        {"max_internal_knots": True},
        {"degree": 0},
        {"gradient_steps": -1},
        {"paper_initial_knots": -1},
        {"paper_admm_iterations": 0},
        {"paper_lambda_bisections": 0},
        {"paper_relocation_iterations": 0},
        {"park_shape_weight": -0.1},
        {"park_shape_weight": float("nan")},
        {"liang_dense_knots": -1},
        {"liang_initial_knots": -1},
        {"liang_curvature_weight": 1.1},
        {"liang_feature_samples": 2},
        {"dung_max_error": -1.0},
        {"dung_max_error": float("nan")},
        {"dung_scan_intervals": 0},
        {"dung_optimization_iterations": -1},
        {"luo_eta": -0.1},
        {"luo_de_population": 4},
        {"luo_de_iterations": -1},
        {"luo_seed": -1},
        {"published_feasibility_safeguard": 1},
    ],
)
def test_invalid_configuration_is_rejected(kwargs: dict[str, object]) -> None:
    with pytest.raises(ValueError):
        _run("uniform_gradient_pruning", **kwargs)


def test_liang_initial_knots_cannot_exceed_dispatcher_cap() -> None:
    with pytest.raises(ValueError, match="must not exceed"):
        _run("liang_feature_iki_2017_adaptation", liang_initial_knots=3)


@pytest.mark.parametrize(
    "method",
    (
        "dung_direct_knot_2017_adaptation",
        "luo_linf_de_2022_adaptation",
    ),
)
def test_common_safeguard_recovers_collapsed_published_adaptations(
    method: str,
) -> None:
    points = _collapse_regression_points()
    options = dict(
        mse_tolerance=1e-4,
        max_internal_knots=28,
        paper_initial_knots=28,
        paper_admm_iterations=15,
        paper_lambda_bisections=1,
        paper_relocation_iterations=1,
        dung_scan_intervals=2,
        dung_optimization_iterations=1,
        luo_de_population=5,
        luo_de_iterations=1,
    )
    native = baselines.run_published_baseline(
        method,
        points,
        published_feasibility_safeguard=False,
        **options,
    )
    safeguarded = baselines.run_published_baseline(
        method, points, published_feasibility_safeguard=True, **options
    )

    assert float(native.fit.fit_mse) > options["mse_tolerance"]
    assert float(safeguarded.fit.fit_mse) <= options["mse_tolerance"] + 1e-12
    assert native.fit.internal_knots.numel() < safeguarded.fit.internal_knots.numel()
    assert safeguarded.fit.internal_knots.numel() <= options["paper_initial_knots"]
    assert safeguarded.diagnostics["comparison_feasibility_safeguard_used"] is True
    assert safeguarded.diagnostics["comparison_feasibility_native_k"] == int(
        native.fit.internal_knots.numel()
    )
    assert safeguarded.diagnostics["comparison_feasibility_native_mse"] == pytest.approx(
        float(native.fit.fit_mse)
    )
    assert safeguarded.diagnostics["comparison_feasibility_refit_count"] > 0
    assert "not part of the cited method" in safeguarded.diagnostics[
        "comparison_feasibility_safeguard_role"
    ]


def test_kang_fixed_error_infeasibility_is_reported_without_nonpaper_rescue() -> None:
    points = _collapse_regression_points()
    # This concrete curve previously received a hidden long-cluster retention
    # repair. The source fixed-Err test becomes infeasible after earlier merges
    # under the finite vector solver. Do not raise Err or return a repaired fit.
    with pytest.raises(ValueError, match="Kang Algorithm 3 interval sparse solve is infeasible"):
        baselines.run_published_baseline(
            "kang_sparse_2015_adaptation", points,
            mse_tolerance=1e-4, max_internal_knots=28, paper_initial_knots=28,
            paper_admm_iterations=15, paper_lambda_bisections=1,
            paper_relocation_iterations=1,
            paper_relocation_algorithm="general",
        )


def test_unknown_method_and_wrong_numeric_dtype_are_rejected() -> None:
    with pytest.raises(ValueError, match="unknown baseline"):
        _run("not-a-method")
    with pytest.raises(ValueError, match="CPU float64"):
        baselines.run_published_baseline(
            "yeh_feature_cdf_2020", _points().float(), mse_tolerance=1e-4
        )
